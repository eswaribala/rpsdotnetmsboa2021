# dotnet-core-prometheus-grafana
A tutorial repo to use .NET Core 2.2, Prometheus and Grafana to show metrics of your Web APIs

The article that talks about this is on Medium.com at https://medium.com/@dale.bingham_30375/net-core-web-api-metrics-with-prometheus-and-grafana-fe84a52d9843. 

# Prerequisites

To use this project you need to have Docker, Docker Compose, and .NET Core 2.2 setup on whatever computer you wish to use.